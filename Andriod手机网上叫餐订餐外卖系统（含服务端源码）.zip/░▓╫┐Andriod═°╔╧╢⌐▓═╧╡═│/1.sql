/*
SQLyog 企业版 - MySQL GUI v8.14 
MySQL - 5.5.13 : Database - foodserver
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`foodserver` /*!40100 DEFAULT CHARACTER SET gbk */;

USE `foodserver`;

/*Table structure for table `admins` */

DROP TABLE IF EXISTS `admins`;

CREATE TABLE `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=gbk;

/*Data for the table `admins` */

insert  into `admins`(`id`,`userName`,`password`) values (3,'1','1');

/*Table structure for table `dingdan` */

DROP TABLE IF EXISTS `dingdan`;

CREATE TABLE `dingdan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `myid` int(11) DEFAULT NULL,
  `totle` double DEFAULT NULL,
  `dates` datetime DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL,
  `state` varchar(10) DEFAULT '未发货',
  `pj` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=gbk;

/*Data for the table `dingdan` */

insert  into `dingdan`(`id`,`myid`,`totle`,`dates`,`phone`,`address`,`type`,`state`,`pj`) values (6,16,11,'2012-05-20 21:37:59','18897678','2383','网银直接支付','已发货',NULL),(7,18,11,'2012-05-20 21:45:33','1221432425','234235+','网银直接支付','已发货','非常满意5分');

/*Table structure for table `dingdanmore` */

DROP TABLE IF EXISTS `dingdanmore`;

CREATE TABLE `dingdanmore` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `dingdanid` int(11) DEFAULT NULL,
  `gname` varchar(30) DEFAULT NULL,
  `count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=gbk;

/*Data for the table `dingdanmore` */

insert  into `dingdanmore`(`id`,`dingdanid`,`gname`,`count`) values (10,6,'1',1),(11,7,'1',1);

/*Table structure for table `goods` */

DROP TABLE IF EXISTS `goods`;

CREATE TABLE `goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `gname` varchar(30) DEFAULT NULL,
  `gurl` varchar(100) DEFAULT NULL,
  `gprice` double DEFAULT NULL,
  `gcount` int(11) DEFAULT NULL,
  `gtype` varchar(10) DEFAULT NULL,
  `lx` varchar(30) DEFAULT NULL,
  `gs` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=gbk;

/*Data for the table `goods` */

insert  into `goods`(`id`,`gname`,`gurl`,`gprice`,`gcount`,`gtype`,`lx`,`gs`) values (21,'1','http://10.0.2.2:8080/FoodServer/goods/1.jpg',11,10,'1',NULL,NULL),(22,'2','http://10.0.2.2:8080/FoodServer/goods/2.jpg',22,22,'1',NULL,NULL);

/*Table structure for table `gwc` */

DROP TABLE IF EXISTS `gwc`;

CREATE TABLE `gwc` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) DEFAULT NULL,
  `goodsName` varchar(30) DEFAULT NULL,
  `gcount` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=gbk;

/*Data for the table `gwc` */

insert  into `gwc`(`id`,`userid`,`goodsName`,`gcount`) values (14,14,'123',0),(15,16,'1',1),(16,18,'1',1);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `userName` varchar(30) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `rname` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=gbk;

/*Data for the table `users` */

insert  into `users`(`id`,`userName`,`password`,`phone`,`address`,`rname`) values (18,'123','123','2325tter+','12345678+','123 ');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
