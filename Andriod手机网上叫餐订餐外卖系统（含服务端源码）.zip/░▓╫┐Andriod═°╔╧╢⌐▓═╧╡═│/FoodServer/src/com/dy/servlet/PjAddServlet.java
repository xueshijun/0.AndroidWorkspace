package com.dy.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dy.util.DBUtil;

/**
 * Servlet implementation class PjAddServlet
 */
public class PjAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PjAddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  		// TODO Auto-generated method stub
  		this.doPost(request, response);
  	}

  	/**
  	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
  	 */
  	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
  		// TODO Auto-generated method stub
  		String ddid = URLDecoder.decode(request.getParameter("ddid"),"UTF-8");
		String pj = URLDecoder.decode(request.getParameter("pj"),"UTF-8");
		String pjstr="";
		if(pj!=null){
			if("5".equals(pj)){
				pjstr="�ǳ�����5��";
			}else if("4".equals(pj)){
				pjstr="����4��";
			}else if("3".equals(pj)){
				pjstr="������3��";
			}else if("2".equals(pj)){
				pjstr="һ��2��";
			}else if("1".equals(pj)){
				pjstr="������1��";
			}
		}
		
		String sql = "update dingdan set pj='"+pjstr+"' where id="+ddid;
		DBUtil util = new DBUtil();
		Connection conn = util.openConnection();
		PrintWriter out = response.getWriter();
		String result = "0";
		try {
				Statement stmt = conn.createStatement();
				stmt.executeUpdate(sql);
				 result = "1";
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			result = "2";
		}finally {
			util.closeConn(conn);
		}	
		out.print(result);
	}
}
